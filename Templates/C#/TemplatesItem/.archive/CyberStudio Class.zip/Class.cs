﻿#region using
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Runtime.CompilerServices;

#endregion

// username: $username$
// created:  $time$

namespace $rootnamespace$
{
	public class $safeitemrootname$
	{
	#region private fields



	#endregion

	#region ctor

		public $safeitemname$() { }

	#endregion

	#region public properties



	#endregion

	#region private properties



	#endregion

	#region public methods



	#endregion

	#region private methods



	#endregion

	#region event consuming



	#endregion

	#region event publishing



	#endregion

	#region system overrides

		public override string ToString()
		{
			return "this is $safeitemname$";
		}

	#endregion
	}
}
