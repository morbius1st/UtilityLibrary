﻿#region + Using Directives
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#endregion

// user name: $username$
// created:   $time$

namespace $rootnamespace$
{
	public class $safeitemname$
	{
	}
}
